<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/* load the MX_Router class */
require APPPATH."../bismillah/php_ci//MX/Router.php";

class Bismillah_Router extends MX_Router {}
